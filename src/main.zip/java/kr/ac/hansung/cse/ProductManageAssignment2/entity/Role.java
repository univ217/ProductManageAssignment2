package kr.ac.hansung.cse.ProductManageAssignment2.entity;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
